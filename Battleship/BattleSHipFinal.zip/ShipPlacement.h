//
// Created by george on 6/10/19.
//

#ifndef UNTITLED13_SHIPPLACEMENT_H
#define UNTITLED13_SHIPPLACEMENT_H

namespace BattleShipGame{
    class Player;

    class ShipPlacement {
    public:
        ShipPlacement() ;
        int rowStart,rowEnd,colStart,colEnd;

    };

}
#endif //UNTITLED13_SHIPPLACEMENT_H
