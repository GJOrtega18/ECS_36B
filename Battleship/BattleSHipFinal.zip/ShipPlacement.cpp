//
// Created by george on 6/10/19.
//

#include "ShipPlacement.h"


BattleShipGame::ShipPlacement::ShipPlacement(): rowStart(0), rowEnd(0),
    colStart(0), colEnd(0){

}
