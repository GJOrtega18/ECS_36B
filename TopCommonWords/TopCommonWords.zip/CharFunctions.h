//
// Created by george on 4/10/19.
//

#ifndef CLASS_NOTES_CHARFUNCTIONS_H
#define CLASS_NOTES_CHARFUNCTIONS_H

;

bool isupper(char c);
bool islower(char c);
bool isalpha(char c);
bool isdigit(char c);
bool isalnum(char c);
char toupper(char c);
char tolower(char c);

#endif //CLASS_NOTES_CHARFUNCTIONS_H
